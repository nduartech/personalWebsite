import r from"interests";import{createComponent as e}from"solid-js";const m=t=>e(r,{props:t});export{m as default};
