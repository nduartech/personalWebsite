import{n as a}from"./hoisted.C1PoabJt.js";import{p as e}from"./index.BG2nPUTX.js";window.addEventListener("navigate",t=>{e(t.detail),setTimeout(a(t.detail),300)});
