import r from"software-eng";import{createComponent as t}from"solid-js";const m=o=>t(r,{props:o});export{m as default};
