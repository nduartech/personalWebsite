import{i}from"./index.BG2nPUTX.js";i();
