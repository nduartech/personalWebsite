import{j as r}from"./q-CfXuNiTC.js";import{k as t}from"./q-CfXuNiTC.js";const e=()=>{const[o]=r();return o.onClick()};export{t as _hW,e as s_nn9NEIX3Zz4};
