import{c as o,q as r,_ as t}from"./q-CfXuNiTC.js";const a=o(r(()=>t(()=>import("./q-CDRl52YU.js"),[]),"s_1rK2CPfrAlQ"));export{a as NavButton};
