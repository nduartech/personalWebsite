import{j as e}from"./q-CfXuNiTC.js";import{k as c}from"./q-CfXuNiTC.js";const t=()=>{const[o]=e();return o()};export{c as _hW,t as s_z08XJ26WjK0};
