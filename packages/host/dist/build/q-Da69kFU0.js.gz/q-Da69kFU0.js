import{c as o,q as _,_ as r}from"./q-CfXuNiTC.js";const e=o(_(()=>r(()=>import("./q-CXJwISSJ.js"),[]),"s_eQEjCdXow7I"));export{e as Nav};
