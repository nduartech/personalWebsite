import{j as t}from"./q-CfXuNiTC.js";import{k as a}from"./q-CfXuNiTC.js";const r=()=>{const[o]=t();return o()};export{a as _hW,r as s_7SxtZtp8IKw};
